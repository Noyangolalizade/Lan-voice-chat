const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 6e6 });

app.use(express.static(path.join(__dirname, 'public')));

// roomName -> room object
const rooms = new Map();

function createRoom(name, password) {
  const room = {
    name,
    password: password && password.trim() ? password.trim() : null,
    ownerId: null,
    settings: { regularMicEnabled: true },
    members: new Map(), // socketId -> { name, role, forceMuted }
    wbActions: [],
  };
  rooms.set(name, room);
  return room;
}

function publicMemberList(room) {
  return Array.from(room.members.entries()).map(([id, m]) => ({
    id, name: m.name, role: m.role, forceMuted: !!m.forceMuted, game: m.game || null,
  }));
}

function canManage(role) {
  return role === 'owner' || role === 'admin';
}

io.on('connection', (socket) => {
  let currentRoomName = null;
  let userName = null;

  socket.on('join', ({ room: roomName, name, password }) => {
    roomName = String(roomName || 'general').trim() || 'general';
    userName = String(name || 'کاربر').slice(0, 24);

    let room = rooms.get(roomName);
    let isNewRoom = false;
    if (!room) {
      room = createRoom(roomName, password);
      isNewRoom = true;
    }

    if (!isNewRoom && room.password) {
      if (password !== room.password) {
        socket.emit('join-error', { message: 'رمز عبور کانال اشتباه است.' });
        return;
      }
    }

    currentRoomName = roomName;
    socket.join(roomName);

    const role = isNewRoom ? 'owner' : 'regular';
    if (isNewRoom) room.ownerId = socket.id;

    for (const [id] of room.members) {
      io.to(id).emit('peer-joined', { id: socket.id, name: userName, role });
    }

    const existing = publicMemberList(room);
    room.members.set(socket.id, { name: userName, role, forceMuted: false, game: null });

    socket.emit('room-info', {
      members: existing,
      self: { id: socket.id, name: userName, role },
      room: roomName,
      settings: room.settings,
      hasPassword: !!room.password,
      wbActions: room.wbActions,
    });

    socket.to(roomName).emit('chat-system', { text: `${userName} وارد کانال شد`, ts: Date.now() });
  });

  socket.on('signal', ({ to, data }) => {
    if (!to) return;
    io.to(to).emit('signal', { from: socket.id, data });
  });

  socket.on('chat-message', ({ text }) => {
    if (!currentRoomName || !text) return;
    const room = rooms.get(currentRoomName);
    if (!room) return;
    io.to(currentRoomName).emit('chat-message', {
      from: socket.id, name: userName, text: String(text).slice(0, 1000), ts: Date.now(),
    });
  });

  socket.on('mute-state', ({ muted }) => {
    if (!currentRoomName) return;
    socket.to(currentRoomName).emit('peer-mute-state', { id: socket.id, muted: !!muted });
  });

  socket.on('set-game', ({ game }) => {
    const room = rooms.get(currentRoomName);
    if (!room) return;
    const me = room.members.get(socket.id);
    if (!me) return;
    const clean = String(game || '').trim().slice(0, 40);
    me.game = clean || null;
    io.to(currentRoomName).emit('peer-game-changed', { id: socket.id, game: me.game });
  });

  socket.on('speaking', ({ speaking }) => {
    if (!currentRoomName) return;
    socket.to(currentRoomName).emit('peer-speaking', { id: socket.id, speaking: !!speaking });
  });

  // ----- Room settings (owner/admin only) -----
  socket.on('update-settings', (payload = {}) => {
    const room = rooms.get(currentRoomName);
    if (!room) return;
    const me = room.members.get(socket.id);
    if (!me || !canManage(me.role)) return;

    if (typeof payload.regularMicEnabled === 'boolean') {
      room.settings.regularMicEnabled = payload.regularMicEnabled;
    }
    if (typeof payload.password === 'string' && me.role === 'owner') {
      room.password = payload.password.trim() ? payload.password.trim() : null;
    }

    io.to(currentRoomName).emit('settings-updated', {
      settings: room.settings,
      hasPassword: !!room.password,
    });
  });

  socket.on('set-role', ({ targetId, role }) => {
    const room = rooms.get(currentRoomName);
    if (!room) return;
    const me = room.members.get(socket.id);
    if (!me || !canManage(me.role)) return;
    const target = room.members.get(targetId);
    if (!target || target.role === 'owner') return;
    if (!['admin', 'special', 'regular'].includes(role)) return;

    target.role = role;
    io.to(currentRoomName).emit('peer-role-changed', { id: targetId, role });
  });

  socket.on('force-mute', ({ targetId, muted }) => {
    const room = rooms.get(currentRoomName);
    if (!room) return;
    const me = room.members.get(socket.id);
    if (!me || !canManage(me.role)) return;
    const target = room.members.get(targetId);
    if (!target) return;
    target.forceMuted = !!muted;
    io.to(targetId).emit('you-force-muted', { muted: !!muted });
    io.to(currentRoomName).emit('peer-mute-state', { id: targetId, muted: !!muted });
    io.to(currentRoomName).emit('peer-force-mute-state', { id: targetId, muted: !!muted });
  });

  // ----- Whiteboard (owner/admin/special only) -----
  socket.on('wb-action', (action) => {
    const room = rooms.get(currentRoomName);
    if (!room || !action) return;
    const me = room.members.get(socket.id);
    if (!me || !['owner', 'admin', 'special'].includes(me.role)) return;

    room.wbActions.push(action);
    if (room.wbActions.length > 4000) room.wbActions.shift();
    socket.to(currentRoomName).emit('wb-action', action);
  });

  socket.on('wb-clear', () => {
    const room = rooms.get(currentRoomName);
    if (!room) return;
    const me = room.members.get(socket.id);
    if (!me || !['owner', 'admin', 'special'].includes(me.role)) return;
    room.wbActions = [];
    io.to(currentRoomName).emit('wb-clear');
  });

  socket.on('disconnect', () => {
    if (currentRoomName && rooms.has(currentRoomName)) {
      const room = rooms.get(currentRoomName);
      const wasOwner = room.ownerId === socket.id;
      room.members.delete(socket.id);
      socket.to(currentRoomName).emit('peer-left', { id: socket.id });
      if (userName) {
        socket.to(currentRoomName).emit('chat-system', { text: `${userName} از کانال خارج شد`, ts: Date.now() });
      }
      if (wasOwner && room.members.size > 0) {
        const [newOwnerId, newOwner] = room.members.entries().next().value;
        newOwner.role = 'owner';
        room.ownerId = newOwnerId;
        io.to(currentRoomName).emit('peer-role-changed', { id: newOwnerId, role: 'owner' });
        io.to(currentRoomName).emit('chat-system', { text: `${newOwner.name} مالک جدید کانال شد`, ts: Date.now() });
      }
      if (room.members.size === 0) rooms.delete(currentRoomName);
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`سرور کانال روی پورت ${PORT} فعال شد`);
  console.log(`آدرس محلی: http://localhost:${PORT}`);
});
