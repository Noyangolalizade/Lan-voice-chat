const socket = io();

let localStream = null;
let screenStream = null;
let peers = {};        // id -> RTCPeerConnection
let audioEls = {};     // id -> <audio>
let screenTiles = {};  // id -> { wrap, video }
let members = {};      // id -> { name, role, forceMuted, game }
let selfId = null;
let selfName = null;
let manuallyMuted = false;
let selfForceMuted = false;
let roomSettings = { regularMicEnabled: true };
let roomHasPassword = false;
let audioContext = null;

const GAMES = [
  'Counter-Strike 2', 'Valorant', 'Minecraft', 'Fortnite', 'PUBG: Battlegrounds',
  'PUBG Mobile', 'GTA V', 'GTA Online', 'League of Legends', 'Dota 2',
  'Overwatch 2', 'Call of Duty: Warzone', 'Call of Duty: Modern Warfare III',
  'Apex Legends', 'Rainbow Six Siege', 'Rocket League', 'EA Sports FC 26',
  'eFootball', 'Among Us', 'Roblox', 'World of Warcraft', 'Rust',
  'ARK: Survival Ascended', 'Escape from Tarkov', 'Palworld', 'Elden Ring',
  "Baldur's Gate 3", 'Stardew Valley', 'Terraria', 'Team Fortress 2',
  'Brawl Stars', 'Clash Royale', 'Clash of Clans', 'Free Fire', 'Genshin Impact',
];

// روی LAN واقعی یا شبکه‌ی مجازی پکت‌رفت همه روی یک "شبکه" هستند،
// پس نیازی به سرور STUN/TURN خارجی نیست.
const ICE_SERVERS = [];

/* ===== عناصر DOM ===== */
const joinScreen = document.getElementById('join-screen');
const appScreen = document.getElementById('app-screen');
const joinForm = document.getElementById('join-form');
const nameInput = document.getElementById('name-input');
const roomInput = document.getElementById('room-input');
const passwordInput = document.getElementById('password-input');
const joinError = document.getElementById('join-error');

const channelLabel = document.getElementById('channel-label');
const peerCountEl = document.getElementById('peer-count');
const participantList = document.getElementById('participant-list');
const chatLog = document.getElementById('chat-log');
const chatForm = document.getElementById('chat-form');
const chatInput = document.getElementById('chat-input');
const muteBtn = document.getElementById('mute-btn');
const screenshareBtn = document.getElementById('screenshare-btn');
const leaveBtn = document.getElementById('leave-btn');
const statusLed = document.getElementById('status-led');
const selfVu = document.getElementById('self-vu');
const screensStrip = document.getElementById('screens-strip');

const drawerToggle = document.getElementById('drawer-toggle');
const sidebar = document.getElementById('sidebar');
const sidebarBackdrop = document.getElementById('sidebar-backdrop');

const settingsBtn = document.getElementById('settings-btn');
const settingsModal = document.getElementById('settings-modal');
const passwordRow = document.getElementById('password-row');
const settingsPasswordInput = document.getElementById('settings-password-input');
const savePasswordBtn = document.getElementById('save-password-btn');
const passwordOwnerNote = document.getElementById('password-owner-note');
const regularMicToggle = document.getElementById('regular-mic-toggle');
const settingsMemberList = document.getElementById('settings-member-list');

const whiteboardBtn = document.getElementById('whiteboard-btn');
const whiteboardModal = document.getElementById('whiteboard-modal');
const wbToolbar = document.getElementById('wb-toolbar');
const wbStage = document.getElementById('wb-stage');
const wbCanvas = document.getElementById('wb-canvas');
const wbCtx = wbCanvas.getContext('2d');
const wbObjectsLayer = document.getElementById('wb-objects-layer');
const wbColor = document.getElementById('wb-color');
const wbSize = document.getElementById('wb-size');
const wbClearBtn = document.getElementById('wb-clear-btn');
const wbImageInput = document.getElementById('wb-image-input');
const wbViewOnlyNote = document.getElementById('wb-view-only-note');

const gameBtn = document.getElementById('game-btn');
const gameModal = document.getElementById('game-modal');
const gameSelect = document.getElementById('game-select');
const gameCustomInput = document.getElementById('game-custom-input');
const gameSaveBtn = document.getElementById('game-save-btn');

let wbTool = 'draw';
let wbDrawing = false;
let wbLast = null;
let wbScale = 1;
let wbObjects = {}; // id -> { type, x, y, w, h, text, color, size, src, el }

const ROLE_LABELS = { owner: 'مالک', admin: 'ادمین', special: 'ویژه', regular: 'معمولی' };

/* ===== ورود ===== */
joinForm.addEventListener('submit', (e) => {
  e.preventDefault();
  selfName = nameInput.value.trim() || 'کاربر';
  const room = roomInput.value.trim() || 'general';
  const password = passwordInput.value;

  joinError.classList.add('hidden');
  socket.emit('join', { room, name: selfName, password });
});

socket.on('join-error', ({ message }) => {
  joinError.textContent = message;
  joinError.classList.remove('hidden');
});

socket.on('room-info', async ({ members: existing, self, room, settings, hasPassword, wbActions }) => {
  selfId = self.id;
  roomSettings = settings || { regularMicEnabled: true };
  roomHasPassword = !!hasPassword;

  joinScreen.classList.add('hidden');
  appScreen.classList.remove('hidden');
  channelLabel.textContent = room;
  statusLed.classList.add('online');

  addParticipant(self.id, self.name, self.role, true, false, self.game);

  if (canUseMic()) await ensureLocalStream();

  existing.forEach((m) => {
    addParticipant(m.id, m.name, m.role, false, m.forceMuted, m.game);
    createPeerConnection(m.id);
  });

  updatePeerCount();
  applyRoleUI();

  // بازسازی تخته از تاریخچه
  (wbActions || []).forEach(replayWbAction);
});

socket.on('peer-joined', ({ id, name, role }) => {
  addParticipant(id, name, role, false);
  createPeerConnection(id);
  updatePeerCount();
});

socket.on('peer-left', ({ id }) => {
  removeParticipant(id);
  if (peers[id]) { peers[id].close(); delete peers[id]; }
  if (audioEls[id]) { audioEls[id].remove(); delete audioEls[id]; }
  removeScreenTile(id);
  updatePeerCount();
});

/* ===== سیگنالینگ WebRTC (Perfect Negotiation) ===== */
function createPeerConnection(id) {
  if (peers[id]) return peers[id];
  const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
  peers[id] = pc;

  pc.polite = selfId < id;
  pc.makingOffer = false;
  pc.ignoreOffer = false;

  if (localStream) {
    localStream.getTracks().forEach((track) => pc.addTrack(track, localStream));
  }
  if (screenStream) {
    screenStream.getTracks().forEach((track) => pc.addTrack(track, screenStream));
  }

  pc.onicecandidate = (e) => {
    if (e.candidate) socket.emit('signal', { to: id, data: e.candidate.toJSON() });
  };

  pc.ontrack = (e) => {
    if (e.track.kind === 'video') {
      addScreenTile(id, e.streams[0]);
      e.track.addEventListener('ended', () => removeScreenTile(id));
      return;
    }
    let audioEl = audioEls[id];
    if (!audioEl) {
      audioEl = document.createElement('audio');
      audioEl.autoplay = true;
      document.body.appendChild(audioEl);
      audioEls[id] = audioEl;
    }
    audioEl.srcObject = e.streams[0];
  };

  pc.onnegotiationneeded = async () => {
    try {
      pc.makingOffer = true;
      await pc.setLocalDescription();
      socket.emit('signal', { to: id, data: pc.localDescription });
    } catch (err) {
      console.error('خطا در negotiation:', err);
    } finally {
      pc.makingOffer = false;
    }
  };

  return pc;
}

socket.on('signal', async ({ from, data }) => {
  const pc = createPeerConnection(from);
  try {
    if (data.type === 'offer' || data.type === 'answer') {
      const offerCollision = data.type === 'offer' && (pc.makingOffer || pc.signalingState !== 'stable');
      pc.ignoreOffer = !pc.polite && offerCollision;
      if (pc.ignoreOffer) return;

      await pc.setRemoteDescription(data);
      if (data.type === 'offer') {
        await pc.setLocalDescription();
        socket.emit('signal', { to: from, data: pc.localDescription });
      }
    } else if (data.candidate !== undefined) {
      try {
        await pc.addIceCandidate(data);
      } catch (err) {
        if (!pc.ignoreOffer) console.error('خطای ICE candidate:', err);
      }
    }
  } catch (err) {
    console.error('خطای سیگنالینگ:', err);
  }
});

/* ===== میکروفون و مجوزها ===== */
function canUseMic() {
  const me = members[selfId];
  if (!me) return false;
  if (selfForceMuted) return false;
  if (me.role === 'owner' || me.role === 'admin' || me.role === 'special') return true;
  return !!roomSettings.regularMicEnabled;
}

async function ensureLocalStream() {
  if (localStream) return localStream;
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch (err) {
    appendSystemChat('دسترسی به میکروفون ممکن نشد: ' + err.message);
    return null;
  }
  Object.values(peers).forEach((pc) => {
    localStream.getTracks().forEach((track) => pc.addTrack(track, localStream));
  });
  setupSelfVu();
  updateMicState();
  return localStream;
}

function updateMicState() {
  muteBtn.classList.remove('hidden');
  const allowed = canUseMic();

  if (!allowed) {
    muteBtn.disabled = true;
    muteBtn.textContent = selfForceMuted ? 'میکروفون توسط مدیر قطع شد' : 'میکروفون غیرفعال است';
    muteBtn.classList.add('active');
    if (localStream) localStream.getAudioTracks().forEach((t) => { t.enabled = false; });
    return;
  }

  muteBtn.disabled = false;
  if (!localStream) {
    muteBtn.textContent = 'میکروفون روشن';
    return;
  }

  const enabled = !manuallyMuted;
  localStream.getAudioTracks().forEach((t) => { t.enabled = enabled; });
  muteBtn.classList.toggle('active', !enabled);
  muteBtn.textContent = enabled ? 'میکروفون روشن' : 'میکروفون خاموش';
}

muteBtn.addEventListener('click', async () => {
  if (!canUseMic()) return;
  if (!localStream) await ensureLocalStream();
  manuallyMuted = !manuallyMuted;
  updateMicState();
  socket.emit('mute-state', { muted: manuallyMuted });
  const el = participantList.querySelector(`[data-id="${selfId}"]`);
  if (el) el.classList.toggle('muted', manuallyMuted);
});

socket.on('you-force-muted', ({ muted }) => {
  selfForceMuted = muted;
  updateMicState();
});

function setupSelfVu() {
  if (audioContext) return;
  audioContext = new (window.AudioContext || window.webkitAudioContext)();
  const source = audioContext.createMediaStreamSource(localStream);
  const analyser = audioContext.createAnalyser();
  analyser.fftSize = 512;
  source.connect(analyser);

  const data = new Uint8Array(analyser.frequencyBinCount);
  let speaking = false;

  function tick() {
    analyser.getByteFrequencyData(data);
    let sum = 0;
    for (let i = 0; i < data.length; i++) sum += data[i];
    const avg = sum / data.length;
    const level = Math.min(1, avg / 60);
    selfVu.style.transform = `scaleX(${level})`;

    const isSpeaking = level > 0.12 && canUseMic() && !manuallyMuted;
    if (isSpeaking !== speaking) {
      speaking = isSpeaking;
      socket.emit('speaking', { speaking });
      const el = participantList.querySelector(`[data-id="${selfId}"]`);
      if (el) el.classList.toggle('speaking', speaking);
    }
    requestAnimationFrame(tick);
  }
  tick();
}

/* ===== لیست حاضرین ===== */
function addParticipant(id, name, role, isSelf, forceMuted, game) {
  members[id] = { name, role, forceMuted: !!forceMuted, game: game || null };
  if (participantList.querySelector(`[data-id="${id}"]`)) {
    updateParticipantRole(id, role);
    return;
  }
  const li = document.createElement('li');
  li.className = 'participant';
  li.dataset.id = id;
  li.innerHTML =
    '<span class="dot"></span>' +
    `<span class="p-name">${escapeHtml(name)}${isSelf ? ' (شما)' : ''}</span>` +
    `<span class="p-game${game ? '' : ' hidden'}">${escapeHtml(game || '')}</span>` +
    `<span class="p-role role-${role}">${ROLE_LABELS[role] || role}</span>` +
    '<span class="p-bars"><i></i><i></i><i></i></span>';
  participantList.appendChild(li);
}

function updateParticipantGame(id, game) {
  if (members[id]) members[id].game = game || null;
  const el = participantList.querySelector(`[data-id="${id}"] .p-game`);
  if (el) {
    el.textContent = game || '';
    el.classList.toggle('hidden', !game);
  }
}

function updateParticipantRole(id, role) {
  if (members[id]) members[id].role = role;
  const el = participantList.querySelector(`[data-id="${id}"] .p-role`);
  if (el) {
    el.textContent = ROLE_LABELS[role] || role;
    el.className = `p-role role-${role}`;
  }
  if (id === selfId) {
    applyRoleUI();
    updateMicState();
  }
  renderSettingsMemberList();
}

function removeParticipant(id) {
  delete members[id];
  const el = participantList.querySelector(`[data-id="${id}"]`);
  if (el) el.remove();
  renderSettingsMemberList();
}

function updatePeerCount() {
  peerCountEl.textContent = toFarsiDigits(participantList.children.length);
}

socket.on('peer-role-changed', ({ id, role }) => {
  if (!members[id]) return;
  updateParticipantRole(id, role);
  const who = id === selfId ? 'شما' : (members[id] ? members[id].name : '');
  if (role === 'owner') appendSystemChat(`${who} اکنون مالک کانال است`);
});

socket.on('peer-mute-state', ({ id, muted }) => {
  const el = participantList.querySelector(`[data-id="${id}"]`);
  if (el) el.classList.toggle('muted', muted);
});

socket.on('peer-force-mute-state', ({ id, muted }) => {
  if (members[id]) members[id].forceMuted = muted;
  renderSettingsMemberList();
});

socket.on('peer-speaking', ({ id, speaking }) => {
  const el = participantList.querySelector(`[data-id="${id}"]`);
  if (el) el.classList.toggle('speaking', speaking);
});

socket.on('peer-game-changed', ({ id, game }) => {
  updateParticipantGame(id, game);
});

/* ===== چت متنی ===== */
socket.on('chat-message', ({ from, name, text, ts }) => {
  appendChat(name, text, ts, from === selfId);
});
socket.on('chat-system', ({ text, ts }) => appendSystemChat(text, ts));

function appendChat(name, text, ts, isSelf) {
  const div = document.createElement('div');
  div.className = 'msg' + (isSelf ? ' self' : '');
  div.innerHTML =
    `<span class="msg-meta">${escapeHtml(name)} · ${formatTime(ts)}</span>` +
    `<span class="msg-text">${escapeHtml(text)}</span>`;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}

function appendSystemChat(text, ts) {
  const div = document.createElement('div');
  div.className = 'msg system';
  div.innerHTML = `<span class="msg-text">${escapeHtml(text)}</span>`;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
}

chatForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = chatInput.value.trim();
  if (!text) return;
  socket.emit('chat-message', { text });
  chatInput.value = '';
});

leaveBtn.addEventListener('click', () => window.location.reload());

/* ===== درِ کشویی لیست حاضرین (موبایل) ===== */
function openDrawer() {
  sidebar.classList.add('open');
  sidebarBackdrop.classList.remove('hidden');
}
function closeDrawer() {
  sidebar.classList.remove('open');
  sidebarBackdrop.classList.add('hidden');
}
drawerToggle.addEventListener('click', openDrawer);
sidebarBackdrop.addEventListener('click', closeDrawer);

/* ===== تنظیمات کانال ===== */
function applyRoleUI() {
  const me = members[selfId];
  const canManage = !!me && (me.role === 'owner' || me.role === 'admin');
  settingsBtn.classList.toggle('hidden', !canManage);

  const isOwner = !!me && me.role === 'owner';
  passwordRow.classList.toggle('hidden', !isOwner);
  passwordOwnerNote.classList.toggle('hidden', !canManage || isOwner);

  const canDrawWb = !!me && ['owner', 'admin', 'special'].includes(me.role);
  wbToolbar.classList.toggle('hidden', !canDrawWb);
  wbViewOnlyNote.classList.toggle('hidden', canDrawWb);
  wbCanvas.style.cursor = canDrawWb ? 'crosshair' : 'default';
}

settingsBtn.addEventListener('click', () => {
  regularMicToggle.checked = !!roomSettings.regularMicEnabled;
  settingsPasswordInput.value = '';
  settingsPasswordInput.placeholder = roomHasPassword ? 'رمز فعلی تنظیم شده — برای تغییر بنویسید' : 'رمز جدید (خالی = بدون رمز)';
  openModal('settings-modal');
  renderSettingsMemberList();
});

regularMicToggle.addEventListener('change', () => {
  socket.emit('update-settings', { regularMicEnabled: regularMicToggle.checked });
});

savePasswordBtn.addEventListener('click', () => {
  socket.emit('update-settings', { password: settingsPasswordInput.value });
  settingsPasswordInput.value = '';
});

socket.on('settings-updated', ({ settings, hasPassword }) => {
  roomSettings = settings;
  roomHasPassword = hasPassword;
  updateMicState();
  if (!settingsModal.classList.contains('hidden')) {
    regularMicToggle.checked = !!roomSettings.regularMicEnabled;
    settingsPasswordInput.placeholder = roomHasPassword ? 'رمز فعلی تنظیم شده — برای تغییر بنویسید' : 'رمز جدید (خالی = بدون رمز)';
  }
});

function renderSettingsMemberList() {
  if (settingsModal.classList.contains('hidden')) return;
  settingsMemberList.innerHTML = '';
  Object.entries(members).forEach(([id, m]) => {
    const li = document.createElement('li');
    li.className = 'settings-member-row';

    const nameSpan = document.createElement('span');
    nameSpan.className = 'p-name';
    nameSpan.textContent = m.name + (id === selfId ? ' (شما)' : '');
    li.appendChild(nameSpan);

    if (m.role === 'owner') {
      const badge = document.createElement('span');
      badge.className = 'p-role role-owner';
      badge.textContent = 'مالک';
      li.appendChild(badge);
    } else {
      const select = document.createElement('select');
      ['admin', 'special', 'regular'].forEach((r) => {
        const opt = document.createElement('option');
        opt.value = r;
        opt.textContent = ROLE_LABELS[r];
        if (r === m.role) opt.selected = true;
        select.appendChild(opt);
      });
      select.addEventListener('change', () => {
        socket.emit('set-role', { targetId: id, role: select.value });
      });
      li.appendChild(select);

      const muteBtnEl = document.createElement('button');
      muteBtnEl.type = 'button';
      muteBtnEl.className = 'force-mute-btn' + (m.forceMuted ? ' active' : '');
      muteBtnEl.textContent = m.forceMuted ? 'باز کردن میکروفون' : 'قطع میکروفون';
      muteBtnEl.addEventListener('click', () => {
        socket.emit('force-mute', { targetId: id, muted: !m.forceMuted });
      });
      li.appendChild(muteBtnEl);
    }

    settingsMemberList.appendChild(li);
  });
}

/* ===== تخته ===== */
whiteboardBtn.addEventListener('click', () => {
  openModal('whiteboard-modal');
  requestAnimationFrame(wbUpdateScale);
});
window.addEventListener('resize', wbUpdateScale);

function wbUpdateScale() {
  const rect = wbCanvas.getBoundingClientRect();
  if (!rect.width) return;
  wbScale = rect.width / wbCanvas.width;
  Object.values(wbObjects).forEach((obj) => {
    if (obj.type === 'text') applyTextStyle(obj);
  });
}

wbToolbar.addEventListener('click', (e) => {
  const btn = e.target.closest('.seg-btn[data-tool]');
  if (!btn) return;
  wbTool = btn.dataset.tool;
  wbToolbar.querySelectorAll('.seg-btn[data-tool]').forEach((b) => b.classList.toggle('active', b === btn));
});

wbClearBtn.addEventListener('click', () => {
  socket.emit('wb-clear');
});
socket.on('wb-clear', () => {
  wbCtx.clearRect(0, 0, wbCanvas.width, wbCanvas.height);
  Object.keys(wbObjects).forEach((id) => deleteObject({ id }));
});

function canEditWb() {
  const me = members[selfId];
  return !!me && ['owner', 'admin', 'special'].includes(me.role);
}

function wbPos(e) {
  const rect = wbCanvas.getBoundingClientRect();
  const scaleX = wbCanvas.width / rect.width;
  const scaleY = wbCanvas.height / rect.height;
  const point = e.touches ? e.touches[0] : e;
  return { x: (point.clientX - rect.left) * scaleX, y: (point.clientY - rect.top) * scaleY };
}

function drawSegment({ x1, y1, x2, y2, color, size }) {
  wbCtx.save();
  wbCtx.globalCompositeOperation = 'source-over';
  wbCtx.strokeStyle = color;
  wbCtx.lineWidth = size;
  wbCtx.lineCap = 'round';
  wbCtx.beginPath();
  wbCtx.moveTo(x1, y1);
  wbCtx.lineTo(x2, y2);
  wbCtx.stroke();
  wbCtx.restore();
}

function eraseSegment({ x1, y1, x2, y2, size }) {
  wbCtx.save();
  wbCtx.globalCompositeOperation = 'destination-out';
  wbCtx.lineWidth = size;
  wbCtx.lineCap = 'round';
  wbCtx.beginPath();
  wbCtx.moveTo(x1, y1);
  wbCtx.lineTo(x2, y2);
  wbCtx.stroke();
  wbCtx.restore();
}

/* ---- اشیای قابل جابجایی (متن و عکس) ---- */
function wbNewId() {
  return `${selfId || 'x'}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function positionObjectEl(obj) {
  obj.el.style.left = (obj.x / wbCanvas.width * 100) + '%';
  obj.el.style.top = (obj.y / wbCanvas.height * 100) + '%';
  if (obj.type === 'image') {
    obj.el.style.width = (obj.w / wbCanvas.width * 100) + '%';
    obj.el.style.height = (obj.h / wbCanvas.height * 100) + '%';
  }
}

function applyTextStyle(obj) {
  const inner = obj.el.querySelector('.wb-object-text');
  inner.style.color = obj.color;
  inner.style.fontSize = Math.max(10, obj.size * 6 * wbScale) + 'px';
}

function makeObjectDraggable(obj) {
  let dragging = false;
  let offsetX = 0;
  let offsetY = 0;
  let lastSent = 0;

  obj.el.addEventListener('pointerdown', (e) => {
    if (!canEditWb()) return;
    dragging = true;
    obj.el.setPointerCapture(e.pointerId);
    const pos = wbPos(e);
    offsetX = pos.x - obj.x;
    offsetY = pos.y - obj.y;
    e.stopPropagation();
  });

  obj.el.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const pos = wbPos(e);
    obj.x = pos.x - offsetX;
    obj.y = pos.y - offsetY;
    positionObjectEl(obj);
    const now = Date.now();
    if (now - lastSent > 80) {
      lastSent = now;
      sendWbAction({ type: 'move', id: obj.id, x: obj.x, y: obj.y });
    }
    e.stopPropagation();
  });

  ['pointerup', 'pointercancel'].forEach((ev) => {
    obj.el.addEventListener(ev, (e) => {
      if (!dragging) return;
      dragging = false;
      sendWbAction({ type: 'move', id: obj.id, x: obj.x, y: obj.y });
      e.stopPropagation();
    });
  });
}

function addDeleteHandle(obj) {
  const del = document.createElement('button');
  del.type = 'button';
  del.className = 'wb-object-delete';
  del.textContent = '✕';
  del.addEventListener('pointerdown', (e) => e.stopPropagation());
  del.addEventListener('click', (e) => {
    e.stopPropagation();
    if (!canEditWb()) return;
    sendWbAction({ type: 'delete', id: obj.id });
    deleteObject({ id: obj.id });
  });
  obj.el.appendChild(del);
}

function createTextObject(action, isRemote) {
  if (wbObjects[action.id]) return;
  const el = document.createElement('div');
  el.className = 'wb-object';
  const inner = document.createElement('div');
  inner.className = 'wb-object-text';
  inner.textContent = action.text;
  el.appendChild(inner);

  const obj = { id: action.id, type: 'text', x: action.x, y: action.y, text: action.text, color: action.color, size: action.size, el };
  wbObjects[action.id] = obj;
  positionObjectEl(obj);
  applyTextStyle(obj);
  addDeleteHandle(obj);
  makeObjectDraggable(obj);
  wbObjectsLayer.appendChild(el);
}

function createImageObject(action) {
  if (wbObjects[action.id]) return;
  const el = document.createElement('div');
  el.className = 'wb-object';
  const img = document.createElement('img');
  img.src = action.src;
  img.draggable = false;
  el.appendChild(img);

  const obj = { id: action.id, type: 'image', x: action.x, y: action.y, w: action.w, h: action.h, src: action.src, el };
  wbObjects[action.id] = obj;
  positionObjectEl(obj);
  addDeleteHandle(obj);
  makeObjectDraggable(obj);
  wbObjectsLayer.appendChild(el);
}

function moveObject({ id, x, y }) {
  const obj = wbObjects[id];
  if (!obj) return;
  obj.x = x;
  obj.y = y;
  positionObjectEl(obj);
}

function deleteObject({ id }) {
  const obj = wbObjects[id];
  if (!obj) return;
  obj.el.remove();
  delete wbObjects[id];
}

function replayWbAction(action) {
  if (action.type === 'segment') drawSegment(action);
  else if (action.type === 'erase') eraseSegment(action);
  else if (action.type === 'text') createTextObject(action);
  else if (action.type === 'image') createImageObject(action);
  else if (action.type === 'move') moveObject(action);
  else if (action.type === 'delete') deleteObject(action);
}

function sendWbAction(action) {
  socket.emit('wb-action', action);
}
socket.on('wb-action', replayWbAction);

wbCanvas.addEventListener('pointerdown', (e) => {
  if (!canEditWb()) return;
  if (wbTool === 'draw' || wbTool === 'erase') {
    wbDrawing = true;
    wbLast = wbPos(e);
  } else if (wbTool === 'text') {
    const pos = wbPos(e);
    const text = prompt('متن مورد نظر را بنویسید:');
    if (text && text.trim()) {
      const action = { type: 'text', id: wbNewId(), x: pos.x, y: pos.y, text: text.trim(), color: wbColor.value, size: Number(wbSize.value) };
      createTextObject(action);
      sendWbAction(action);
    }
  }
});

wbCanvas.addEventListener('pointermove', (e) => {
  if (!wbDrawing || !canEditWb()) return;
  if (wbTool !== 'draw' && wbTool !== 'erase') return;
  const pos = wbPos(e);
  if (wbTool === 'erase') {
    const action = { type: 'erase', x1: wbLast.x, y1: wbLast.y, x2: pos.x, y2: pos.y, size: Number(wbSize.value) * 3 };
    eraseSegment(action);
    sendWbAction(action);
  } else {
    const action = { type: 'segment', x1: wbLast.x, y1: wbLast.y, x2: pos.x, y2: pos.y, color: wbColor.value, size: Number(wbSize.value) };
    drawSegment(action);
    sendWbAction(action);
  }
  wbLast = pos;
});

['pointerup', 'pointerleave'].forEach((ev) => {
  wbCanvas.addEventListener(ev, () => { wbDrawing = false; });
});

wbImageInput.addEventListener('change', () => {
  if (!canEditWb()) return;
  const file = wbImageInput.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const maxW = 320;
      const scale = Math.min(1, maxW / img.width);
      const w = img.width * scale;
      const h = img.height * scale;
      const x = 40;
      const y = 40;
      const tmp = document.createElement('canvas');
      tmp.width = w; tmp.height = h;
      tmp.getContext('2d').drawImage(img, 0, 0, w, h);
      const src = tmp.toDataURL('image/jpeg', 0.8);
      const action = { type: 'image', id: wbNewId(), x, y, w, h, src };
      createImageObject(action);
      sendWbAction(action);
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
  wbImageInput.value = '';
});

/* ===== مودال‌ها ===== */
function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
}
function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
}
document.querySelectorAll('[data-close-modal]').forEach((btn) => {
  btn.addEventListener('click', () => closeModal(btn.dataset.closeModal));
});
document.querySelectorAll('.modal-backdrop').forEach((backdrop) => {
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) backdrop.classList.add('hidden');
  });
});

/* ===== ابزارهای کمکی ===== */
function formatTime(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
}
function toFarsiDigits(n) {
  const map = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return String(n).replace(/[0-9]/g, (d) => map[d]);
}
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
